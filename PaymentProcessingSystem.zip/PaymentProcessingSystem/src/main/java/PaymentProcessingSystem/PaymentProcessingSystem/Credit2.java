package PaymentProcessingSystem.PaymentProcessingSystem;

public class Credit2 {

}
