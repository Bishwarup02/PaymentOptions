package PaymentProcessingSystem.PaymentProcessingSystem;

public class Credit1 {

}
