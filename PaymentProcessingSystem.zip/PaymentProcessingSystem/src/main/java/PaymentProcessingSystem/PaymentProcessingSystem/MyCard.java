package PaymentProcessingSystem.PaymentProcessingSystem;

public interface MyCard {
	void processPayment(double amount);
}
