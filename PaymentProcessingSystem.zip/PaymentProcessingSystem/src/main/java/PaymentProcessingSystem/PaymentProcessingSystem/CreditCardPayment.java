package PaymentProcessingSystem.PaymentProcessingSystem;

public class CreditCardPayment extends Payment{
	
	CreditCardPayment() {
		super.PaymentType("CreditCard");
	}
	@Override
	public void processPayment(double amount) {
		// TODO Auto-generated method stub
		System.out.println("Processing CreditCard payment of $"+amount);
	}

}
