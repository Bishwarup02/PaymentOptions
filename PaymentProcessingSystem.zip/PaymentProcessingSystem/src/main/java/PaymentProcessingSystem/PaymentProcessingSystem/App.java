package PaymentProcessingSystem.PaymentProcessingSystem;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        CreditCardPayment HDFC=new CreditCardPayment();
        HDFC.processPayment(2345.22);
        PayPalPayment payPal=new PayPalPayment();
        payPal.processPayment(5668.5);
    }
}
