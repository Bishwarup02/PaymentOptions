package PaymentProcessingSystem.PaymentProcessingSystem;

public class PayPalPayment extends Payment{
	
	PayPalPayment() {
		super.PaymentType("PayPalPayment");
	}
	@Override
	public void processPayment(double amount) {
		// TODO Auto-generated method stub
		System.out.println("Processing Paypal payment of $"+amount);

	}

}
