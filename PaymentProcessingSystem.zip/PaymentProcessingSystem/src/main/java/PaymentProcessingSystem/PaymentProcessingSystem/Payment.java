package PaymentProcessingSystem.PaymentProcessingSystem;

public abstract class Payment implements MyCard{
	
	
	String PaymentType;
	public void PaymentType(String PaymentType) {
		this.PaymentType=PaymentType;
	}
	public abstract void processPayment(double amount);
}
